player_manager.AddValidModel( "RIZA BABA", "models/player/askarakter/rizababa.mdl" )
//player_manager.AddValidHands( "RIZA BABA", "models/player/kvkarakter/abdulhey_eller.mdl", 0, "00000000" )